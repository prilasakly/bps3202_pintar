@extends('layouts.app')

@section('title', 'Daftar Indikator')

@section('content')
    <div class="card">
        <h1>Daftar Indikator Data Makro</h1>
        <p>Pilih salah satu indikator untuk melihat tabelnya, atau <a href="{{ route('upload.create') }}">upload data baru</a>.</p>
    </div>

    @foreach ($sidebars as $sidebar)
        <div class="card">
            <h2>{{ $sidebar->nama }}</h2>

            @foreach ($sidebar->subsidebars as $subsidebar)
                <h3 class="subsidebar-title">{{ $subsidebar->nama }}</h3>
                <ul class="list-indikator">
                    @foreach ($subsidebar->indikators as $indikator)
                        <li>
                            <a href="{{ route('indikator.show', $indikator) }}">{{ $indikator->nama_judul }}</a>
                        </li>
                    @endforeach
                </ul>
            @endforeach
        </div>
    @endforeach
@endsection
