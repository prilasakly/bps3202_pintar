@extends('layouts.app')

@section('title', $indikator->nama_judul)

@section('content')
    <div class="card">
        <h1>{{ $indikator->nama_judul }}</h1>
        @if ($indikator->satuan)
            <p>Satuan: {{ $indikator->satuan }}</p>
        @endif

        <form method="get" class="checkbox-tahun">
            <label>Pilih tahun yang ditampilkan:</label>
            @forelse ($tahunTersediaUnik as $tahun)
                <label>
                    <input type="checkbox" name="tahun[]" value="{{ $tahun }}"
                        {{ in_array($tahun, $tahunDipilih) ? 'checked' : '' }}>
                    {{ $tahun }}
                </label>
            @empty
                <p>Belum ada data yang diupload untuk indikator ini.</p>
            @endforelse
            @if ($tahunTersediaUnik->isNotEmpty())
                <button type="submit">Tampilkan</button>
            @endif
        </form>
    </div>

    @if ($periodeDipilih->isNotEmpty())
        <div class="card" style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th rowspan="2">Kecamatan</th>
                        @foreach ($periodeDipilih as $p)
                            <th colspan="{{ $indikator->kolom->count() }}" style="text-align:center;">
                                {{ $p->tahun }}{{ $p->triwulan ? ' - TW'.$p->triwulan : '' }}
                            </th>
                        @endforeach
                    </tr>
                    <tr>
                        @foreach ($periodeDipilih as $p)
                            @foreach ($indikator->kolom as $k)
                                <th>{{ $k->kolom_label }}</th>
                            @endforeach
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach ($indikator->baris as $baris)
                        <tr>
                            <td>{{ $baris->baris_label }}</td>
                            @foreach ($periodeDipilih as $p)
                                @foreach ($indikator->kolom as $k)
                                    <td>{{ $nilaiMap[$baris->id][$p->id][$k->id] ?? '-' }}</td>
                                @endforeach
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
@endsection
