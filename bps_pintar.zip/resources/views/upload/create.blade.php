@extends('layouts.app')

@section('title', 'Upload Data')

@section('content')
    <div class="card">
        <h1>Upload Data Excel</h1>

        @if (session('hasil_import'))
            @php($hasil = session('hasil_import'))
            <div class="alert-{{ $hasil['status'] }}">{{ $hasil['pesan'] }}</div>
        @endif

        @if ($errors->any())
            <div class="alert-gagal">
                <ul style="margin:0;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="post" action="{{ route('upload.store') }}" enctype="multipart/form-data">
            @csrf

            <label for="indikator_id">Indikator tujuan</label>
            <select name="indikator_id" id="indikator_id" required>
                <option value="">-- pilih indikator --</option>
                @foreach ($indikators as $indikator)
                    <option value="{{ $indikator->id }}">
                        {{ $indikator->subsidebar->sidebar->nama }} / {{ $indikator->subsidebar->nama }} / {{ $indikator->nama_judul }}
                    </option>
                @endforeach
            </select>

            <label for="tahun">Tahun data</label>
            <input type="number" name="tahun" id="tahun" min="2000" max="2100" required placeholder="contoh: 2025">

            <label for="triwulan">Triwulan (opsional, kosongkan kalau data tahunan)</label>
            <select name="triwulan" id="triwulan">
                <option value="">-- data tahunan --</option>
                <option value="1">Triwulan 1</option>
                <option value="2">Triwulan 2</option>
                <option value="3">Triwulan 3</option>
                <option value="4">Triwulan 4</option>
            </select>

            <label for="sheet">Nama sheet (opsional, kosongkan untuk pakai sheet pertama)</label>
            <input type="text" name="sheet" id="sheet" placeholder="contoh: 2025">

            <label for="file">File Excel (.xls / .xlsx)</label>
            <input type="file" name="file" id="file" accept=".xls,.xlsx" required>

            <label style="font-weight:normal; margin-top:16px;">
                <input type="checkbox" name="force" value="1" style="width:auto;">
                Timpa data kalau tahun/triwulan ini sudah pernah diupload
            </label>

            <button type="submit">Upload</button>
        </form>
    </div>
@endsection
