<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>@yield('title', 'Data Makro Sukabumi')</title>
    <style>
        body { font-family: Arial, Helvetica, sans-serif; margin: 0; background: #f4f4f2; color: #222; }
        header { background: #1d3557; color: #fff; padding: 14px 24px; }
        header a { color: #fff; text-decoration: none; font-weight: bold; }
        nav.top a { color: #cfe0f5; margin-left: 16px; font-size: 14px; }
        main { max-width: 1100px; margin: 24px auto; padding: 0 16px; }
        .card { background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; font-size: 14px; }
        th, td { border: 1px solid #ddd; padding: 6px 10px; text-align: left; }
        th { background: #f0f0ee; }
        .alert-sukses { background: #e7f5ec; border: 1px solid #7fc99a; color: #16603a; padding: 10px 14px; border-radius: 6px; margin-bottom: 16px; }
        .alert-gagal { background: #fbe9e7; border: 1px solid #e29a90; color: #8a2d1f; padding: 10px 14px; border-radius: 6px; margin-bottom: 16px; }
        .alert-diabaikan { background: #fff6e0; border: 1px solid #e0c56a; color: #6b5108; padding: 10px 14px; border-radius: 6px; margin-bottom: 16px; }
        label { display: block; margin: 12px 0 4px; font-weight: bold; font-size: 14px; }
        input, select { padding: 6px 8px; font-size: 14px; width: 100%; max-width: 420px; box-sizing: border-box; }
        button { margin-top: 16px; background: #1d3557; color: #fff; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; font-size: 14px; }
        .checkbox-tahun label { display: inline-block; font-weight: normal; margin-right: 14px; }
        .checkbox-tahun input { width: auto; }
        .subsidebar-title { margin-top: 24px; color: #1d3557; }
        .list-indikator { list-style: none; padding-left: 0; }
        .list-indikator li { padding: 4px 0; }
        .list-indikator a { color: #333; text-decoration: none; }
        .list-indikator a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<header>
    <a href="{{ route('indikator.index') }}">Data Makro Kabupaten Sukabumi</a>
    <nav class="top" style="display:inline;">
        <a href="{{ route('indikator.index') }}">Daftar Indikator</a>
        <a href="{{ route('upload.create') }}">Upload Data</a>
    </nav>
</header>
<main>
    @yield('content')
</main>
</body>
</html>
