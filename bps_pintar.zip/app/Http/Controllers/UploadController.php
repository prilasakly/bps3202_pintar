<?php

namespace App\Http\Controllers;

use App\Http\Requests\UploadIndikatorRequest;
use App\Models\Indikator;
use App\Services\IndikatorExcelImporter;

class UploadController extends Controller
{
    public function create()
    {
        $indikators = Indikator::with('subsidebar.sidebar')
            ->orderBy('nama_judul')
            ->get();

        return view('upload.create', compact('indikators'));
    }

    public function store(UploadIndikatorRequest $request, IndikatorExcelImporter $importer)
    {
        $indikator = Indikator::findOrFail($request->integer('indikator_id'));
        $file = $request->file('file');

        $hasil = $importer->import(
            indikator: $indikator,
            filePath: $file->getRealPath(),
            tahun: $request->integer('tahun'),
            triwulan: $request->filled('triwulan') ? $request->integer('triwulan') : null,
            namaFileAsli: $file->getClientOriginalName(),
            namaSheet: $request->input('sheet'),
            force: $request->boolean('force'),
        );

        return back()->with('hasil_import', $hasil);
    }
}
